﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Data.SqlClient;


namespace Test_Project
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        //Opens the connection to the database
        //***************
        //
        //      You will have to rename the file path for the database! (line 31)
        //
        //***************
        private SqlConnection StartConnection()
        {
            SqlConnection conn = new SqlConnection(
                "Data Source = (LocalDB)\\MSSQLLocalDB;" +
                "AttachDbFilename = C:\\Job Interview Code\\Guardian Software\\Test Project\\Database\\TestData.mdf;" +
                "Integrated Security = True;");
            conn.Open();
            return conn;
        }


        //Displays all of the names in the database.
        private void Name_Only(object sender, RoutedEventArgs e)
        {
            string data = "";
            SqlCommand cmd = new SqlCommand("SELECT First_Name, Last_Name FROM [Resident_List]", StartConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                data += reader["First_Name"].ToString() + " ";
                data += reader["Last_Name"].ToString();
                data += "\n";
            }
            this.textBlock.Text = data;
        }


        //For Main Street Appartment Only
        private void Main_Street_Only(object sender, RoutedEventArgs e)
        {
            string data = "";
            SqlCommand cmd = new SqlCommand("SELECT * FROM [Resident_List] WHERE Appartment_Address LIKE '%Main St%'", StartConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                data += reader["First_Name"].ToString() + " ";
                data += reader["Last_Name"].ToString() + " ";
                data += reader["Date_of_Birth"].ToString() + " ";
                data += reader["Appartment_Address"].ToString() + " ";
                data += reader["Insurance"].ToString() + " ";
                data += reader["Room_Number"].ToString();
                data += "\n";
            }
            this.textBlock.Text = data;
        }


        //For Park Ave. Appartment Only
        private void Park_Avenue_Only(object sender, RoutedEventArgs e)
        {
            string data = "";
            SqlCommand cmd = new SqlCommand("SELECT * FROM [Resident_List] WHERE Appartment_Address LIKE '%Park Ave%'", StartConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                data += reader["First_Name"].ToString() + " ";
                data += reader["Last_Name"].ToString() + " ";
                data += reader["Date_of_Birth"].ToString() + " ";
                data += reader["Appartment_Address"].ToString() + " ";
                data += reader["Insurance"].ToString() + " ";
                data += reader["Room_Number"].ToString();
                data += "\n";
            }
            this.textBlock.Text = data;
        }


        //For West Boulevard Appartment Only
        private void West_Boulevard_Only(object sender, RoutedEventArgs e)
        {
            string data = "";
            SqlCommand cmd = new SqlCommand("SELECT * FROM [Resident_List] WHERE Appartment_Address LIKE '%West Blvd%'", StartConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                data += reader["First_Name"].ToString() + " ";
                data += reader["Last_Name"].ToString() + " ";
                data += reader["Date_of_Birth"].ToString() + " ";
                data += reader["Appartment_Address"].ToString() + " ";
                data += reader["Insurance"].ToString() + " ";
                data += reader["Room_Number"].ToString();
                data += "\n";
            }
            this.textBlock.Text = data;
        }


        //connects to the local database that was created.
        //Pulls the data from the database in the specified SQL statement.
        private void All_Data(object sender, RoutedEventArgs e)
        {
            string data = "";
            SqlCommand cmd = new SqlCommand("SELECT * FROM [Resident_List]", StartConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                data += reader["First_Name"].ToString() + " ";
                data += reader["Last_Name"].ToString() + " ";
                data += reader["Date_of_Birth"].ToString() + " ";
                data += reader["Appartment_Address"].ToString() + " ";
                data += reader["Insurance"].ToString() + " ";
                data += reader["Room_Number"].ToString();
                data += "\n";
            }
            this.textBlock.Text = data;
        }


        //used to clear the textblock.
        private void Clear(object sender, RoutedEventArgs e)
        {
            this.textBlock.Text = "";
        }
    }
}
